package com.mycompany.studyhub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
