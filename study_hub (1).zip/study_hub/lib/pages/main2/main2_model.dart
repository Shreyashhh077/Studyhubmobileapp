import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'main2_widget.dart' show Main2Widget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Main2Model extends FlutterFlowModel<Main2Widget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Textfield widget.
  FocusNode? textfieldFocusNode;
  TextEditingController? textfieldTextController;
  String? Function(BuildContext, String?)? textfieldTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textfieldFocusNode?.dispose();
    textfieldTextController?.dispose();
  }
}
