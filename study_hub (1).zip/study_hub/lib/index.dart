// Export pages
export '/pages/projectsoverview/projectsoverview_widget.dart'
    show ProjectsoverviewWidget;
export '/pages/materialsection/materialsection_widget.dart'
    show MaterialsectionWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/main2/main2_widget.dart' show Main2Widget;
export '/study_material_page/study_material_page_widget.dart'
    show StudyMaterialPageWidget;
export '/pages/project_details/project_details_widget.dart'
    show ProjectDetailsWidget;
export '/user_profile/user_profile_widget.dart' show UserProfileWidget;
export '/settings_page/settings_page_widget.dart' show SettingsPageWidget;
export '/editprofile/editprofile_widget.dart' show EditprofileWidget;
export '/changepassword/changepassword_widget.dart' show ChangepasswordWidget;
export '/pages/registration/registration_widget.dart' show RegistrationWidget;
export '/data_struct_study_material/data_struct_study_material_widget.dart'
    show DataStructStudyMaterialWidget;
