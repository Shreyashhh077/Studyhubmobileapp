import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCNsD-kF8iQU2_qIS06T81xYi11cW-OoRQ",
            authDomain: "studyhubapp-project-73fca.firebaseapp.com",
            projectId: "studyhubapp-project-73fca",
            storageBucket: "studyhubapp-project-73fca.firebasestorage.app",
            messagingSenderId: "869761052529",
            appId: "1:869761052529:web:96f9c5a3b985115c01d0d0",
            measurementId: "G-CKTGCWFVGN"));
  } else {
    await Firebase.initializeApp();
  }
}
